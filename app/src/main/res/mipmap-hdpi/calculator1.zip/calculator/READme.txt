
       Simple Calculator application 
This Android application facilitates basic arithmetic and trigonometric calculations within a user-friendly interface.
Key Features:
 *Trigonometric function support with degree/radian mode toggle.
 *Displays appropriate error messages using (e.g., division by zero) 
   Alert Dialog and Toast.
 *Clean and intuitive user interface for easy navigation.
Getting Started:
  1.Open the project in Android Studio.
  2.Build and run the application on an emulator or device.
 




Name - Hana Ayalew
ID- DBU1401373